import java.util.Random;

public class LotreBoard {
    private char[][] board;
    private boolean[][] revealed;
    private int[][] data;
    private final int ROWS = 4;
    private final int COLS = 5;
    private final int TOTAL_BOM = 2;

    public LotreBoard() {
        board = new char[ROWS][COLS];
        revealed = new boolean[ROWS][COLS];
        data = new int[ROWS][COLS];
        generateBoard();
    }

    public void generateBoard() {
        Random rand = new Random();
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                data[i][j] = 0;
                revealed[i][j] = false;
                board[i][j] = '*';
            }
        }

        int placedBombs = 0;
        while (placedBombs < TOTAL_BOM) {
            int r = rand.nextInt(ROWS);
            int c = rand.nextInt(COLS);

            if (data[r][c] == 0) {
                data[r][c] = 1;
                placedBombs++;
            }
        }
    }

    public void displayBoard() {
        System.out.print("    ");
        for (int i = 0; i < COLS; i++) {
            System.out.printf(" %d  ", i);
        }
        System.out.println();
        System.out.println("   +" + "---+".repeat(COLS));

        for (int i = 0; i < ROWS; i++) {
            System.out.printf(" %d |", i);
            for (int j = 0; j < COLS; j++) {
                System.out.printf(" %c |", board[i][j]);
            }
            System.out.println();
            System.out.println("   +" + "---+".repeat(COLS));
        }
    }

    public boolean guess(int row, int col) {
        if (row < 0 || row >= ROWS || col < 0 || col >= COLS) {
            System.out.println("Tebakan di luar batas papan!");
            return true;
        }

        if (revealed[row][col]) {
            System.out.println("Kotak telah dibuka sebelumnya!");
            return true;
        }

        revealed[row][col] = true;
        if (data[row][col] == 1) {
            board[row][col] = 'X';
            return false;
        } else {
            board[row][col] = 'O';
            return true;
        }
    }

    public boolean isAlreadyRevealed(int row, int col) {
        if (row < 0 || row >= ROWS || col < 0 || col >= COLS) {
            return false;
        }
        return revealed[row][col];
    }

    public boolean isGameOver() {
        int countRevealed = 0;
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                if (revealed[i][j] && data[i][j] == 0) {
                    countRevealed++;
                }
            }
        }
        return countRevealed == (ROWS * COLS - TOTAL_BOM);
    }
}
