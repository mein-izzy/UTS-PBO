import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean playAgain = true;

        System.out.println("Selamat datang di Lotre Gosok Bang Pawwry!");
        while (playAgain) {
            LotreBoard board = new LotreBoard();
            boolean playing = true;
            int maxGuesses = 18;
            int guesses = 0;

            while (playing && guesses < maxGuesses) {
                board.displayBoard();
                System.out.println("Tebakan tersisa: " + (maxGuesses - guesses));
                System.out.print("Masukkan tebakan anda (baris dan kolom) : ");
                int row = scanner.nextInt();
                int col = scanner.nextInt();

                boolean safe = board.guess(row, col);
                if (!board.isAlreadyRevealed(row, col)) {
                    guesses++;
                }

                if (!safe) {
                    System.out.println("BOOM! Anda menemukan BOM! Permainan Berakhir");
                    board.displayBoard();
                    break;
                }

                if (board.isGameOver()) {
                    System.out.println("Selamat! Anda Menang!");
                    board.displayBoard();
                    break;
                }
            }
            System.out.print("Mau main lagi? (y/n): ");
            String response = scanner.next();
            if (!response.equalsIgnoreCase("y")) {
                playAgain = false;
            }
        }
        System.out.println("Terima kasih sudah bermain Lotre Gosok Bang Pawwry!");
        scanner.close();
    }
}
