import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

public class Perusahaan {
    private ArrayList<Karyawan> daftarKaryawan;
    private static final String FILE_NAME = "data_karyawan.dat";
    private final Font fontBesar = new Font("Arial", Font.PLAIN, 16); //supaya fontnya tetap
    private JTable karyawanTable;
    private DefaultTableModel tableModel;

    public Perusahaan() {
        daftarKaryawan = new ArrayList<>();
        loadDataFromFile();
        daftarKaryawan.sort(Comparator.comparingInt(Karyawan::getId));
    }

    public void showGUI() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERRROOORR", "Error", JOptionPane.ERROR_MESSAGE);
        }

        JFrame frame = new JFrame("Sistem Manajemen Karyawan");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 700);
        frame.setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(fontBesar);
        tabbedPane.addTab("Tambah Karyawan", createTambahPanel());
        tabbedPane.addTab("Pencarian & Edit", createPencarianPanel());
        frame.add(tabbedPane, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private JPanel createTambahPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gridPanel = new GridBagConstraints();
        gridPanel.insets = new Insets(10, 10, 10, 10);
        gridPanel.anchor = GridBagConstraints.WEST;

        JLabel titleLabel = new JLabel("Tambah Karyawan Baru");
        titleLabel.setFont(fontBesar.deriveFont(Font.BOLD, 18));
        gridPanel.gridwidth = 2;
        panel.add(titleLabel, gridPanel);

        String[] labels = {"ID Karyawan:", "Nama:", "Posisi:", "Gaji:", "Divisi:", "Tanggal Bergabung:"};
        JComponent[] fields = { //untuk dropdown posisi
                new JTextField(20), new JTextField(20),
                new JComboBox<>(new String[]{"Manajer", "Supervisor", "Staf"}),
                new JTextField(20), new JTextField(20), new JTextField(20)
        };
        for (JComponent field : fields) field.setFont(fontBesar);

        gridPanel.gridwidth = 1;
        for (int i = 0; i < labels.length; i++) {
            gridPanel.gridy = i + 1;
            gridPanel.gridx = 0;
            JLabel label = new JLabel(labels[i]);
            label.setFont(fontBesar);
            panel.add(label, gridPanel);
            gridPanel.gridx = 1;
            panel.add(fields[i], gridPanel);
        }

        JButton tambahButton = new JButton("Tambah Karyawan");
        tambahButton.setFont(fontBesar);
        gridPanel.gridy = labels.length + 1;
        gridPanel.gridx = 0;
        gridPanel.gridwidth = 2;
        gridPanel.anchor = GridBagConstraints.CENTER;
        panel.add(tambahButton, gridPanel);

        tambahButton.addActionListener(e -> {
            try {
                String idText = ((JTextField) fields[0]).getText().trim();
                if (idText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "ID Karyawan tidak boleh kosong!", "ADA YANG KOSONG", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                int id;
                try {
                    id = Integer.parseInt(idText);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "ID Karyawan harus berupa angka!", "ID NYA HARUS ANGKA", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String nama = ((JTextField) fields[1]).getText().trim();
                String posisi = (String) ((JComboBox<?>) fields[2]).getSelectedItem();
                double gaji = Double.parseDouble(((JTextField) fields[3]).getText().trim());
                String divisi = ((JTextField) fields[4]).getText().trim();
                String tanggal = ((JTextField) fields[5]).getText().trim();

                if (nama.isEmpty() || divisi.isEmpty() || tanggal.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Semua field harus diisi!", "WARNING", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (cariKaryawanById(id) != null) {
                    JOptionPane.showMessageDialog(null, "ID karyawan sudah ada!", "WARNING", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                daftarKaryawan.add(new Karyawan(id, nama, posisi, gaji, divisi, tanggal));
                saveDataToFile();
                refreshTableData();
                JOptionPane.showMessageDialog(null, "Karyawan berhasil ditambahkan!", "SUCCESS", JOptionPane.INFORMATION_MESSAGE);

                for (int i = 0; i < fields.length; i++) {
                    if (fields[i] instanceof JTextField) ((JTextField) fields[i]).setText("");
                    if (fields[i] instanceof JComboBox) ((JComboBox<?>) fields[i]).setSelectedIndex(0);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Format gaji tidak valid!", "MASUKIN YG BENER", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "ADA YANG GA BENER", JOptionPane.ERROR_MESSAGE);
            }
        }); return panel;
    }

    private JPanel createPencarianPanel() {
        //mengatur layout untuk panel pencarian
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JTextField searchField = new JTextField(10);
        searchField.setFont(new Font("Arial", Font.PLAIN, 14));

        JComboBox<String> filterCombo = new JComboBox<>(new String[]{"ID", "Nama", "Posisi", "Divisi", "Gaji", "Tanggal Bergabung"});
        filterCombo.setFont(new Font("Arial", Font.PLAIN, 14));

        JButton searchButton = new JButton("Cari");
        searchButton.setFont(new Font("Arial", Font.PLAIN, 14));

        JButton sortButton = new JButton("Urutkan");
        sortButton.setFont(new Font("Arial", Font.PLAIN, 14));

        controlPanel.add(new JLabel("Kata Kunci:"));
        controlPanel.add(searchField);
        controlPanel.add(new JLabel("Filter:"));
        controlPanel.add(filterCombo);
        controlPanel.add(searchButton);
        controlPanel.add(Box.createHorizontalStrut(10));
        controlPanel.add(sortButton);

        String[] columnNames = {"ID", "Nama", "Posisi", "Gaji", "Divisi", "Tanggal Bergabung"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) return Integer.class;
                if (columnIndex == 3) return Double.class;
                return String.class;
            }
        };

        karyawanTable = new JTable(tableModel);
        karyawanTable.setFont(new Font("Arial", Font.PLAIN, 14));
        karyawanTable.setRowHeight(25);
        karyawanTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 16));
        karyawanTable.getTableHeader().setBackground(new Color(70, 130, 180));
        karyawanTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        //mengatur lebar setiap kolom, id, nama, posisi dan lainnya
        karyawanTable.getColumnModel().getColumn(0).setPreferredWidth(40);
        karyawanTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        karyawanTable.getColumnModel().getColumn(2).setPreferredWidth(100);
        karyawanTable.getColumnModel().getColumn(3).setPreferredWidth(80);
        karyawanTable.getColumnModel().getColumn(4).setPreferredWidth(120);
        karyawanTable.getColumnModel().getColumn(5).setPreferredWidth(120);

        karyawanTable.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                //menampilkan gaji dalam format rupiah
                if (value instanceof Double) {
                    value = String.format("Rp%,.2f", (Double)value);
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        });

        JScrollPane tableScrollPane = new JScrollPane(karyawanTable);
        tableScrollPane.setPreferredSize(new Dimension(900, 400));
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton editButton = new JButton("Edit Data");
        JButton deleteButton = new JButton("Hapus Data");

        editButton.setFont(fontBesar);
        deleteButton.setFont(fontBesar);
        actionPanel.add(editButton);
        actionPanel.add(deleteButton);
        refreshTableData();

        searchButton.addActionListener(e -> {
            //field untuk menuliskan nama, atau keyword dari data yang ingin dicari
            String keyword = searchField.getText().trim().toLowerCase();
            String filterBy = (String) filterCombo.getSelectedItem();

            List<Karyawan> filteredList = new ArrayList<>();
            if (keyword.isEmpty()) {
                filteredList.addAll(daftarKaryawan);
            } else {
                for (Karyawan k : daftarKaryawan) {
                    boolean match = false;
                    String fieldValue = "";

                    //untuk mengurutkan berdasarkan nama, posisi, dan lain lain
                    switch (filterBy) {
                        case "ID":
                            try {
                                int searchId = Integer.parseInt(keyword);
                                if (k.getId() == searchId) match = true;
                            } catch (NumberFormatException ex) {
                                JOptionPane.showMessageDialog(null, "ID harus berupa angka!", "Error", JOptionPane.ERROR_MESSAGE);
                            } break;
                        case "Nama":
                            fieldValue = k.getNama().toLowerCase();
                            if (fieldValue.contains(keyword)) match = true; break;
                        case "Posisi":
                            fieldValue = k.getPosisi().toLowerCase();
                            if (fieldValue.contains(keyword)) match = true; break;
                        case "Divisi":
                            fieldValue = k.getDivisi().toLowerCase();
                            if (fieldValue.contains(keyword)) match = true; break;
                        case "Gaji":
                            fieldValue = String.valueOf(k.getGaji());
                            if (fieldValue.contains(keyword)) match = true; break;
                        case "Tanggal Bergabung":
                            fieldValue = k.getTanggalBergabung();
                            if (fieldValue.contains(keyword)) match = true; break;
                    }

                    if (match) {
                        filteredList.add(k);}
                }
            } refreshTableData(filteredList);
        });

        sortButton.addActionListener(e -> {
            String filterBy = (String) filterCombo.getSelectedItem();
            List<Karyawan> sortedList = new ArrayList<>(daftarKaryawan);

            switch (filterBy) {
                case "ID":
                    sortedList.sort(Comparator.comparingInt(Karyawan::getId));
                    break;
                case "Nama":
                    sortedList.sort(Comparator.comparing(k -> k.getNama().toLowerCase()));
                    break;
                case "Posisi":
                    sortedList.sort(Comparator.comparing(k -> k.getPosisi().toLowerCase()));
                    break;
                case "Divisi":
                    sortedList.sort(Comparator.comparing(k -> k.getDivisi().toLowerCase()));
                    break;
                case "Gaji":
                    sortedList.sort(Comparator.comparingDouble(Karyawan::getGaji));
                    break;
                case "Tanggal Bergabung":
                    sortedList.sort((k1, k2) -> {
                        String[] date1 = k1.getTanggalBergabung().split("-");
                        String[] date2 = k2.getTanggalBergabung().split("-");
                        String dateStr1 = date1[2] + date1[1] + date1[0];
                        String dateStr2 = date2[2] + date2[1] + date2[0];
                        return dateStr1.compareTo(dateStr2);
                    }); break;
            } refreshTableData(sortedList);
        });

        editButton.addActionListener(e -> {
            int selectedRow = karyawanTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih karyawan terlebih dahulu!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int id = (Integer) tableModel.getValueAt(selectedRow, 0);
            Karyawan karyawan = cariKaryawanById(id);

            JPanel editPanel = new JPanel(new GridLayout(6, 2, 10, 10));
            JTextField idField = new JTextField(String.valueOf(karyawan.getId()));
            JTextField namaField = new JTextField(karyawan.getNama());
            JComboBox<String> posisiCombo = new JComboBox<>(new String[]{"Manajer", "Supervisor", "Staf"});
            posisiCombo.setSelectedItem(karyawan.getPosisi());
            JTextField gajiField = new JTextField(String.valueOf(karyawan.getGaji()));
            JTextField divisiField = new JTextField(karyawan.getDivisi());
            JTextField tanggalField = new JTextField(karyawan.getTanggalBergabung());

            //form untuk mengisi data yang ingin diedit
            editPanel.add(new JLabel("ID:"));
            editPanel.add(idField);
            editPanel.add(new JLabel("Nama:"));
            editPanel.add(namaField);
            editPanel.add(new JLabel("Posisi:"));
            editPanel.add(posisiCombo);
            editPanel.add(new JLabel("Gaji:"));
            editPanel.add(gajiField);
            editPanel.add(new JLabel("Divisi:"));
            editPanel.add(divisiField);
            editPanel.add(new JLabel("Tanggal Bergabung:"));
            editPanel.add(tanggalField);

            int result = JOptionPane.showConfirmDialog(null, editPanel, "Edit Data Karyawan",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                try {
                    int newId;
                    try {
                        newId = Integer.parseInt(idField.getText().trim());
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "ID harus berupa angka!", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    if (newId != karyawan.getId() && cariKaryawanById(newId) != null) {
                        JOptionPane.showMessageDialog(null, "ID karyawan sudah ada!", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    karyawan.setId(newId);
                    karyawan.setNama(namaField.getText().trim());
                    karyawan.setPosisi((String) posisiCombo.getSelectedItem());
                    karyawan.setGaji(Double.parseDouble(gajiField.getText().trim()));
                    karyawan.setDivisi(divisiField.getText().trim());
                    karyawan.setTanggalBergabung(tanggalField.getText().trim());

                    saveDataToFile();
                    refreshTableData();
                    JOptionPane.showMessageDialog(null, "Data berhasil diupdate!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Format gaji tidak valid!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = karyawanTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih karyawan terlebih dahulu!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            //kalau baris dipilih dan ditekan tombol hapus, program akan memastikan apakah data itu benar benar akan dihapus
            int id = (Integer) tableModel.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(
                    null,
                    "Apakah Anda yakin ingin menghapus karyawan ini?",
                    "Konfirmasi Hapus",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );

            if (confirm == JOptionPane.YES_OPTION) {
                daftarKaryawan.removeIf(k -> k.getId() == id);
                saveDataToFile();
                refreshTableData();
                JOptionPane.showMessageDialog(null, "Karyawan berhasil dihapus!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        panel.add(controlPanel, BorderLayout.NORTH);
        panel.add(tableScrollPane, BorderLayout.CENTER);
        panel.add(actionPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void refreshTableData() { //fungsi untuk merefresh data yang akan dipanggil di fugsi lain
        List<Karyawan> sortedList = new ArrayList<>(daftarKaryawan);
        sortedList.sort(Comparator.comparingInt(Karyawan::getId));
        refreshTableData(sortedList);
    }

    private void refreshTableData(List<Karyawan> karyawanList) { //menambah kolom kalau ada data karyawan baru
        tableModel.setRowCount(0);
        for (Karyawan k : karyawanList) {
            Object[] rowData = {
                    k.getId(), k.getNama(), k.getPosisi(),
                    k.getGaji(), k.getDivisi(), k.getTanggalBergabung()
            }; tableModel.addRow(rowData);
        }
    }

    private Karyawan cariKaryawanById(int id) { //mencari karyawan berdasarkan ID
        for (Karyawan k : daftarKaryawan) {
            if (k.getId() == id) {
                return k;
            }
        } return null;
    }

    private void loadDataFromFile() { // mengambil data yang udah ada ketika kode dijalankan
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            daftarKaryawan = (ArrayList<Karyawan>) ois.readObject();
        } catch (FileNotFoundException e) {
        } catch (IOException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error loading data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveDataToFile() { //untuk menyimpan data ke dalam file
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            daftarKaryawan.sort(Comparator.comparingInt(Karyawan::getId));
            oos.writeObject(daftarKaryawan);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving data: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}