import java.io.Serializable;

public class Karyawan implements Serializable {
    private int id;
    private String nama;
    private String posisi;
    private double gaji;
    private String divisi;
    private String tanggalBergabung;

    public Karyawan(int id, String nama, String posisi, double gaji, String divisi, String tanggalBergabung) {
        this.id = id;
        this.nama = nama;
        setPosisi(posisi);
        this.gaji = gaji;
        this.divisi = divisi;
        this.tanggalBergabung = tanggalBergabung;
    }

    public int getId() {
        return id; }
    public void setId(int id) {
        this.id = id; }

    public String getNama() {
        return nama; }
    public void setNama(String nama) {
        this.nama = nama; }

    public String getPosisi() {
        return posisi; }
    public void setPosisi(String posisi) {
        if (posisi.equalsIgnoreCase("Manajer") || posisi.equalsIgnoreCase("Supervisor") || posisi.equalsIgnoreCase("Staf")) {
            this.posisi = posisi;
        } else {
            throw new IllegalArgumentException("Posisi harus Manajer, Supervisor, atau Staf");
        }
    }
    public double getGaji() {
        return gaji; }
    public void setGaji(double gaji) {
        if (gaji < 0) throw new IllegalArgumentException("Gaji tidak boleh negatif");
        this.gaji = gaji;
    }

    public String getDivisi() {
        return divisi; }
    public void setDivisi(String divisi) {
        this.divisi = divisi; }

    public String getTanggalBergabung() {
        return tanggalBergabung; }
    public void setTanggalBergabung(String tanggalBergabung) {
        this.tanggalBergabung = tanggalBergabung; }

}