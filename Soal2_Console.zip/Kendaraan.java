public class Kendaraan {
    private String jenis;
    private double lamaParkir;

    public Kendaraan(String jenis) {
        this.jenis = jenis;
    }

    public double getLamaParkir() {
        return lamaParkir;
    }

    public int getJamParkir() {
        int totalMenit = (int) Math.round(lamaParkir * 60);
        return totalMenit / 60;
    }

    public int getMenitParkir() {
        int totalMenit = (int) Math.round(lamaParkir * 60);
        return totalMenit % 60;
    }

    public int hitungBiayaParkir(double jam) {
        this.lamaParkir = jam;
        int tarif = getTarifPerJam();
        int total = (int)(tarif * lamaParkir);

        if (lamaParkir > 5) {
            total = total - (total / 10); // Diskon 10%
        }

        return total;
    }

    public int hitungBiayaParkir(double jamMasuk, double jamKeluar) {
        lamaParkir = hitungDurasi(jamMasuk, jamKeluar);
        return hitungBiayaParkir(lamaParkir);
    }

    //menghitung lama parkir
    private double hitungDurasi(double jamMasuk, double jamKeluar) {
        int jamIn = (int) jamMasuk;
        int menitIn = (int) Math.round((jamMasuk - jamIn) * 100);
        int jamOut = (int) jamKeluar;
        int menitOut = (int) Math.round((jamKeluar - jamOut) * 100);
        int totalMenitMasuk = jamIn * 60 + menitIn;
        int totalMenitKeluar = jamOut * 60 + menitOut;
        int selisihMenit = totalMenitKeluar - totalMenitMasuk;
        if (selisihMenit < 0) {
            selisihMenit += 24 * 60; // Jika keluar lewat tengah malam
        }
        return selisihMenit / 60.0;
    }

    private int getTarifPerJam() {
        switch (jenis.toLowerCase()) {
            case "motor":
                return 2000;
            case "mobil":
                return 5000;
            case "truk":
                return 10000;
            default:
                return 0;
        }
    }
}
