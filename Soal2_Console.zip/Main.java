import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        StringBuilder parkingSummary = new StringBuilder(); // Untuk menyimpan semua summary ke file
        int totalKendaraan = 0;
        int totalBiayaParkir = 0;

        System.out.println("======== Welcome to ParkingChan ========");

        boolean lanjut = true;
        while (lanjut) { //proses inputan yang harus diisi oleh user
            System.out.print("\nEnter vehicle type (Motor/Mobil/Truk) : ");
            String jenis = input.nextLine();

            Kendaraan kendaraan = new Kendaraan(jenis);
            System.out.print("Enter Duration (Manual/Time): ");
            String metode = input.nextLine();

            int biaya = 0;
            if (metode.equalsIgnoreCase("Manual")) {
                System.out.print("Enter Duration (in hour): ");
                double jam = input.nextDouble();
                biaya = kendaraan.hitungBiayaParkir(jam);
                input.nextLine(); 
            } else if (metode.equalsIgnoreCase("Time")) {
                System.out.print("Enter entry time (e.g. 12.30): ");
                double jamMasuk = input.nextDouble();
                System.out.print("Enter exit time (e.g. 14.45): ");
                double jamKeluar = input.nextDouble();
                biaya = kendaraan.hitungBiayaParkir(jamMasuk, jamKeluar);
                input.nextLine(); 
            } else {
                System.out.println("Invalid input method!");
                continue;
            }

            //Ringkasan iaya parkir
            System.out.println("\n---- PARKING SUMMARY ----");
            System.out.println("Vehicle Type  : " + jenis);
            System.out.printf("Parking Time  : %d jam %d menit\n",
                    kendaraan.getLamaParkir(),
                    kendaraan.getJamParkir(),
                    kendaraan.getMenitParkir()
            );
            System.out.printf("Total Fee     : Rp%.0f\n", (double)biaya);

            // Format yang akan di simpan di summary txt
            parkingSummary.append("Vehicle Type  : ").append(jenis).append("\n")
                    .append(String.format("Parking Time  : %.2f hour(s) (%d jam %d menit)\n",
                            kendaraan.getLamaParkir(),
                            kendaraan.getJamParkir(),
                            kendaraan.getMenitParkir()))
                    .append(String.format("Total Fee     : Rp%.0f\n\n", (double)biaya));

            totalKendaraan++;
            totalBiayaParkir += biaya;

            System.out.print("\nAdd another vehicle? (y/n): ");
            String jawab = input.nextLine();
            if (!jawab.equalsIgnoreCase("y")) {
                lanjut = false;
            }
        }

        System.out.println("\n======= FINAL REPORT =======");
        System.out.println("Total Vehicle Final   : " + totalKendaraan);
        System.out.println("Total Parking Fees Final : Rp" + (double)totalBiayaParkir);
        System.out.println("Thank You.....");

        parkingSummary.append("======= FINAL REPORT =======\n")
                .append("Total Vehicle Final   : ").append(totalKendaraan).append("\n")
                .append("Total Parking Fees Final : Rp").append((double)totalBiayaParkir).append("\n")
                .append("Thank You.....\n");

        // Simpan ke dalam file TXT
        try {
            FileWriter writer = new FileWriter("parking_summary.txt");
            writer.write(parkingSummary.toString());
            writer.close();
            System.out.println("\nParking summary saved to 'parking_summary.txt'");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to file.");
            e.printStackTrace();
        }
        input.close();
    }
}